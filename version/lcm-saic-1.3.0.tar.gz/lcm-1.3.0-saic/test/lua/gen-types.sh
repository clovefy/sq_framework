#!/bin/sh

lcm-gen -l ../types/lcmtest/*.lcm
